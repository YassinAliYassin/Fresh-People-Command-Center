/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Client {
  id: number;
  name: string;
  contactPerson: string;
  email: string;
  phone: string;
}

export interface Venue {
  id: string;
  name: string;
  address: string;
  capacity: number;
  tier: string; // "Luxury Class" | "Premium Estate" | "Aesthetic Loft" | "Superyacht Deck"
  notes: string;
}

export interface Event {
  id: string;
  title: string;
  clientId: string;
  venueId: string;
  date: string; // YYYY-MM-DD
  startTime: string; // HH:MM
  endTime: string; // HH:MM
  staffIds: string[]; // Mapped staff allocations
  notes: string;
  clientRequirements?: string; // Other requirements requested by the client
  googleEventId?: string; // ID if synced with Google Calendar
  appleEventId?: string; // ID if synced with Apple Calendar / iCloud
  status?: 'Pending' | 'Confirmed' | 'Canceled';
  isDirectBooking?: boolean; // If booked directly on the spot
  staffRSVPs?: Record<string, 'Pending' | 'Available' | 'Unavailable'>; // Tracking responses per staff member
}

export interface ActivityLog {
  id: string;
  timestamp: string;
  operator: string;
  type: 'auth' | 'event_create' | 'event_delete' | 'sync' | 'direct_booking' | 'call' | 'staff_reply';
  message: string;
  isUrgent?: boolean;
}

export interface Staff {
  id: number;
  fullName: string;
  phone: string;
  role: 'Bartender' | 'Server' | 'Barista' | 'Mixologist' | 'Barback' | 'Setup Team' | 'Promoter' | 'Usher';
  rate?: number;
  notes?: string;
  created_at?: string;
}

export interface StaffAssignment {
  id: number;
  eventId: string;
  staffId: number;
  fullName: string;
  phone: string;
  role: string;
  shiftType: 'Full Shift' | 'Shift A' | 'Shift B' | 'Double Shift';
  status: 'Pending' | 'Confirmed' | 'Unavailable';
  totalHours?: number;
  earnedAmount?: number;
  dateWorked?: string;
  staff?: Staff;
}

export interface MiscExpense {
  id: string;
  category: 'Transport' | 'Food' | 'Equipment' | 'Materials' | 'Other';
  description: string;
  amount: number;
  date: string; // YYYY-MM-DD
}

export interface BackendEvent {
  id: string;
  title: string;
  date: string;
  duration: number;
  staffName?: string;  // Legacy single-assignment
  staffPhone?: string;
  staffEmail?: string;
  assignedStaff?: StaffAssignment[];  // Many-to-many roster
  clientId?: number;
  clientName?: string;
  clientBudget?: number;
  clientPhone?: string;
  clientEmail?: string;
  dressCode: string;  // From server (camelCase)
  uniformType?: string;
  arrivalTime: string;
  miscExpenses?: MiscExpense[];
  totalEventCost?: number;
  netProfit?: number;
  createdAt?: string;
}
